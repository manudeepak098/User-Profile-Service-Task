package com.userprofileservice.controller;

import static com.userprofileservice.constants.UserProfileConstants.USER_PROFILE_BASE_URL;

import com.userprofileservice.exception.BadRequestException;
import com.userprofileservice.model.ErrorResponse;
import com.userprofileservice.model.UserProfile;
import com.userprofileservice.service.UserProfileServiceImpl;
import com.userprofileservice.validator.AccountsRequestValidators;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import javax.validation.Valid;
import java.util.Optional;
import java.util.UUID;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping(USER_PROFILE_BASE_URL)
public class UserProfileController {

  private static final String TAGS = "API : User Profile";

  @InitBinder("userProfile")
  public void setupBinder(WebDataBinder binder) {
    binder.addValidators(new AccountsRequestValidators());
  }

  @Autowired
  private UserProfileServiceImpl userProfileService;

  @ApiOperation(value = "Get User Profile", notes = "Get User Profile by UserId.", tags = TAGS)
  @GetMapping(value = "/getUserProfile/{userId}", produces = {
      MediaType.APPLICATION_JSON_VALUE})
  @ResponseStatus(HttpStatus.OK)
  @ApiResponses(value = {
      @ApiResponse(code = 200, message = "Fetched User profile", response = UserProfile.class),
      @ApiResponse(code = 400, message = "Invalid User ID", response = ErrorResponse.class),
      @ApiResponse(code = 404, message = "User ID not found", response = ErrorResponse.class),
      @ApiResponse(code = 500, message = "Application error", response = ErrorResponse.class)
  })
  public ResponseEntity<?> getUserProfile(@PathVariable UUID userId) {
    Optional<UserProfile> response = userProfileService.getUserProfileByUserId(userId);
    if (! response.isPresent()) {
      throw new BadRequestException("Invalid UserId in Path Variable");
    }
    return new ResponseEntity<>(response, new HttpHeaders(), HttpStatus.OK);
  }

  @ApiOperation(value = "Upsert User Profile", notes = "Upsert User Profile", tags = TAGS)
  @PostMapping(value = "/upsert", produces = {
      MediaType.APPLICATION_JSON_VALUE})
  @ResponseStatus(HttpStatus.OK)
  @ApiResponses(value = {
      @ApiResponse(code = 200, message = "Upsert User profile", response = UserProfile.class),
      @ApiResponse(code = 400, message = "Invalid User ID", response = ErrorResponse.class),
      @ApiResponse(code = 404, message = "User ID not found", response = ErrorResponse.class),
      @ApiResponse(code = 500, message = "Application error", response = ErrorResponse.class)
  })
  public ResponseEntity<?> upsertUserProfile(@Valid @RequestBody UserProfile userProfile) {
    userProfileService.createOrUpdateUserProfile(userProfile);
    return new ResponseEntity<>(null, new HttpHeaders(), HttpStatus.OK);
  }

}
