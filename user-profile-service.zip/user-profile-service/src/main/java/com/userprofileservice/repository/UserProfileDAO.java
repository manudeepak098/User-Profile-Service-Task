package com.userprofileservice.repository;

import com.userprofileservice.model.UserProfile;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface UserProfileDAO {

  void saveUserProfile(Object content, String fileURL);

  Optional<List<UserProfile>> getAllUserProfiles();

  Optional<UserProfile> getUserProfileByUserId(UUID userProfileId);


}
