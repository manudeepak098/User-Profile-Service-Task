package com.userprofileservice.repository;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.userprofileservice.constants.UserProfileConstants;
import com.userprofileservice.exception.InternalServerException;
import com.userprofileservice.model.UserProfile;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.stereotype.Repository;

@Repository
public class UserProfileDAOImpl implements UserProfileDAO {

  public void saveUserProfile(Object content, String fileURL) {
    String obj = new Gson().toJson(content);
    try (FileWriter myWriter = new FileWriter(fileURL)) {
      myWriter.write(obj);
    } catch (IOException e) {
      throw new InternalServerException("IOException in DAO File While getting User profiles");
    } catch (Exception e) {
      throw new InternalServerException(e.getMessage());
    }
  }

  public Optional<List<UserProfile>> getAllUserProfiles()  {
    try {
      Object obj = new JSONParser().parse(new FileReader(UserProfileConstants.USER_PROFILE_DAO_URI));
      String jsonObject = ((JSONObject) obj).get("value").toString();
      return Optional.ofNullable(new Gson().fromJson(jsonObject, new TypeToken<List<UserProfile>>(){}.getType()));
    } catch (FileNotFoundException e) {
      throw new InternalServerException("FileNotFoundException in DAO File While getting User profiles");
    } catch (Exception e) {
      throw new InternalServerException(e.getMessage());
    }
  }

  public Optional<UserProfile> getUserProfileByUserId(UUID userProfileId) {
    Optional<List<UserProfile>> userProfiles = getAllUserProfiles();
    return userProfiles.flatMap(profiles -> profiles.stream()
        .filter(userProfile -> userProfile.getUserId().equals(userProfileId)).findFirst());
  }
}
