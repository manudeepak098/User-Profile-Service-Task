package com.userprofileservice.validator;


import com.userprofileservice.enums.ValidatorErrorCodes;
import com.userprofileservice.exception.BadRequestException;
import com.userprofileservice.model.UserProfile;
import java.util.Arrays;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import org.springframework.util.ObjectUtils;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;


public class AccountsRequestValidators implements Validator {

  @Override
  public boolean supports(Class<?> clazz) {
    return UserProfile.class.isAssignableFrom(clazz);
  }

  @Override
  public void validate(Object target, Errors errors) {

    UserProfile request = (UserProfile) target;
    if (ObjectUtils.isEmpty(request.getAddress())
        || ObjectUtils.isEmpty(request.getEmail())
        || ObjectUtils.isEmpty(request.getFirstName())
        || ObjectUtils.isEmpty(request.getGender())
        || ObjectUtils.isEmpty(request.getMobileNumber())) {
      throw new BadRequestException("Required Fields are empty.");
    }

    if (! Arrays.asList("male", "female").contains(request.getGender())) {
      throw new BadRequestException("Gender can only be Male or Female.");
    }

    try {
      InternetAddress emailAddr = new InternetAddress(request.getEmail());
      emailAddr.validate();
    } catch (AddressException ex) {
     throw new BadRequestException("Invalid Email Address");
    }
  }
}
