package com.userprofileservice.util;

import java.util.UUID;

public class UUIDUtil {

    public static boolean isValidUUID(String input) {
        try {
            UUID.fromString(input);
            return input.length() == 36;
        } catch (Exception ex) {
            return false;
        }
    }
}
