package com.userprofileservice.enums;


public enum ValidatorErrorCodes {
  NOT_FOUND,
  EMPTY,
  INVALID;
}
