package com.userprofileservice.service;

import com.userprofileservice.constants.UserProfileConstants;
import com.userprofileservice.model.UserProfile;
import com.userprofileservice.repository.UserProfileDAOImpl;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class UserProfileServiceImpl implements UserProfileService{

  @Autowired
  UserProfileDAOImpl userProfileDAO;


  public Optional<List<UserProfile>> getAllUserProfiles() {
    return userProfileDAO.getAllUserProfiles();
  }

  public Optional<UserProfile> getUserProfileByUserId(UUID userProfileId) {
    return userProfileDAO.getUserProfileByUserId(userProfileId);
  }


  @Override
  public void createOrUpdateUserProfile(UserProfile userProfile) {
    //getProfileById == null? create else update
    Optional<UserProfile> userProfile1 = getUserProfileByUserId(userProfile.getUserId());
    Optional<List<UserProfile>> userProfiles = getAllUserProfiles();
    if(userProfile1.isPresent() && userProfile1.get().getUserId().equals(userProfile.getUserId())) {
      userProfiles.get().removeIf(e -> e.getUserId().equals(userProfile.getUserId()));
      userProfile.setLastActivityDate(new Date());
      userProfiles.get().add(userProfile);
      userProfileDAO.saveUserProfile(userProfiles.get(), UserProfileConstants.USER_PROFILE_DAO_URI);
    } else {
      if(! userProfiles.isPresent()) {
        List<UserProfile> up = new ArrayList<>();
        userProfile.setLastActivityDate(new Date());
        up.add(userProfile);
        userProfileDAO.saveUserProfile(up, UserProfileConstants.USER_PROFILE_DAO_URI);
      }
      else {
        userProfile.setLastActivityDate(new Date());
        userProfiles.get().add(userProfile);
        userProfileDAO.saveUserProfile(userProfiles, UserProfileConstants.USER_PROFILE_DAO_URI);
      }
    }
  }
}

