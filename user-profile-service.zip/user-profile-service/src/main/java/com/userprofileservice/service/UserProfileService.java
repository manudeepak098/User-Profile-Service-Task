package com.userprofileservice.service;

import com.userprofileservice.model.UserProfile;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface UserProfileService {

  Optional<UserProfile> getUserProfileByUserId(UUID userProfileId);

  void createOrUpdateUserProfile(UserProfile userProfile);

  Optional<List<UserProfile>> getAllUserProfiles();

}
