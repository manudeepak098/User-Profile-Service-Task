package com.userprofileservice.constants;

public class UserProfileConstants {

  public static final String USER_PROFILE_BASE_URL = "/ecommerce/userprofile";
  public static final String USER_PROFILE_DAO_URI = "userProfileDAO.json";

}
