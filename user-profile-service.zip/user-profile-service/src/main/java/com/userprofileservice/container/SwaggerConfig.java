package com.userprofileservice.container;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.MediaType;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;


@Configuration
@EnableSwagger2
@ComponentScan(basePackages = {"com.userprofileservice"})
class SwaggerConfig implements WebMvcConfigurer {

  private static final Set<String> DEFAULT_PRODUCES = new HashSet<>(
      Arrays.asList(MediaType.APPLICATION_JSON_VALUE));
  private static final Set<String> DEFAULT_CONSUMES = new HashSet<>(
      Arrays.asList(MediaType.APPLICATION_JSON_VALUE));

  @Bean
  public Docket swaggerV1Apis() {
    return new Docket(DocumentationType.SWAGGER_2)
        .groupName("UserProfile Service")
        .produces(DEFAULT_PRODUCES)
        .consumes(DEFAULT_CONSUMES)
        .select()
        .paths(PathSelectors.regex("/.*"))
        .build()
        .genericModelSubstitutes(Optional.class)
        .apiInfo(
            new ApiInfoBuilder().version("v1.0.0").title("Ecommerce API")
                .description("Ecommerce User Profile service API")
                .build())
        .useDefaultResponseMessages(false);
  }
}
