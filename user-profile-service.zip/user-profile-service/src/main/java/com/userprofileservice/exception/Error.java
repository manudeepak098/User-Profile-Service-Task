package com.userprofileservice.exception;

import io.swagger.v3.oas.annotations.media.Schema;


public class Error {

  @Schema(description = "Error type", example = "Request error")
  private String errorType;

  @Schema(description = "Error message", example = "User ID is required")
  private String message;

  @Schema(description = "Error details", example = "User ID is required")
  private String errorDetails;

  public String getErrorType() {
    return errorType;
  }

  public void setErrorType(String errorType) {
    this.errorType = errorType;
  }

  public String getMessage() {
    return message;
  }

  public void setMessage(String message) {
    this.message = message;
  }

  public String getErrorDetails() {
    return errorDetails;
  }

  public void setErrorDetails(String errorDetails) {
    this.errorDetails = errorDetails;
  }
}
