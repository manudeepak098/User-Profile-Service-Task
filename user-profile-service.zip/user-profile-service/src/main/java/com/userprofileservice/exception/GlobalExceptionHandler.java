package com.userprofileservice.exception;

import com.fasterxml.jackson.databind.exc.MismatchedInputException;
import com.google.gson.JsonParseException;
import com.userprofileservice.model.ErrorResponse;
import java.io.NotSerializableException;
import java.util.Arrays;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;


@ControllerAdvice
@RestController
public class GlobalExceptionHandler {

  @ExceptionHandler({BadRequestException.class, NotSerializableException.class, JsonParseException.class, MismatchedInputException.class,
      MethodArgumentNotValidException.class})
  @ResponseBody
  @ResponseStatus(HttpStatus.BAD_REQUEST)
  public ResponseEntity<ErrorResponse> handleHttpMessageNotReadableException(BadRequestException ex) {
    Error error = new Error();
    error.setErrorType("Request Error");
    String exMessage = ObjectUtils.isEmpty(ex.getMessage()) ? "Invalid Data in payLoad" : ex.getMessage();
    error.setMessage(exMessage);
    ErrorResponse errorResponse = new ErrorResponse();
    errorResponse.setErrors(Arrays.asList(error));
    return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
  }

  @ExceptionHandler({Exception.class, InternalServerException.class})
  @ResponseBody
  @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
  public ResponseEntity<ErrorResponse> handleEmailServiceException(InternalServerException ex) {
    Error error = new Error();
    error.setErrorType("Internal Error on User Profile Service");
    error.setMessage(ex.getMessage());
    ErrorResponse errorResponse = new ErrorResponse();
    errorResponse.setErrors(Arrays.asList(error));
    return new ResponseEntity<>(errorResponse, HttpStatus.INTERNAL_SERVER_ERROR);
  }
}
